import React from 'react';
import {View} from 'react-native';
import {SvgXml} from 'react-native-svg';
import {wScale} from '../../../utils/styles/dimensions';

const BackSvg = ({size = wScale(20), color = '#fff'}) => {
  const svgname = `

<svg xmlns="http://www.w3.org/2000/svg" version="1.1" xmlns:xlink="http://www.w3.org/1999/xlink" width="512" height="512" x="0" y="0" viewBox="0 0 492.004 492.004" style="enable-background:new 0 0 512 512" xml:space="preserve" class=""><g transform="matrix(-0.9500000000000003,-1.1634144591899862e-16,1.1634144591899862e-16,-0.9500000000000003,479.7039573669433,479.7038681030274)"><path d="M382.678 226.804 163.73 7.86C158.666 2.792 151.906 0 144.698 0s-13.968 2.792-19.032 7.86l-16.124 16.12c-10.492 10.504-10.492 27.576 0 38.064L293.398 245.9l-184.06 184.06c-5.064 5.068-7.86 11.824-7.86 19.028 0 7.212 2.796 13.968 7.86 19.04l16.124 16.116c5.068 5.068 11.824 7.86 19.032 7.86s13.968-2.792 19.032-7.86L382.678 265c5.076-5.084 7.864-11.872 7.848-19.088.016-7.244-2.772-14.028-7.848-19.108z" fill="#000000" opacity="1" data-original="#000000" class=""></path></g></svg>

    `;
  return (
    <View>
      <SvgXml xml={svgname} width={size} height={size} />
    </View>
  );
};

export default BackSvg;
